Steps to generate your interactive word cloud

1. Open the dist folder
2. Insert a .txt file of your choosing and be sure to name it "text.txt"
3. Run "word_cloud.exe" and a browser instance will run the visualization 